package jdbcchris;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.sql.SQLException;

class JDBCChris extends JFrame implements ActionListener {

    private JButton exportButton = new JButton("Export All Data to CSV");
    private JButton irishPopbyCounty = new JButton("Export Population by County for Each Year");
    private JButton numRecForCellButton = new JButton("2016 Population for County Name: ");
    private JButton popByCountyforYear = new JButton("Population by Each County for Year: ");
    private JTextField countySelector = new JTextField(12);
    private JTextField popNum = new JTextField(12);
    private JButton exitButton = new JButton();
    private Connection con = null;
    private Statement stmt = null;
    private int port = 3306;
    private String dbTable = "/census16prelim";
    private String username = "root";
    private String password = "admin";

    public JDBCChris(String str) {
        super(str);
        getContentPane().setLayout(new GridLayout(3, 2));
        initDBConnection();
        getContentPane().add(exportButton);
        getContentPane().add(irishPopbyCounty);
        getContentPane().add(numRecForCellButton);
        getContentPane().add(countySelector);
        getContentPane().add(popByCountyforYear);
        getContentPane().add(popNum);
        exportButton.addActionListener(this);
        irishPopbyCounty.addActionListener(this);
        numRecForCellButton.addActionListener(this);
        popByCountyforYear.addActionListener(this);
        setSize(500, 300);
        setVisible(true);
        
        //Close nicely
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initDBConnection() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:" + port + dbTable;
            System.out.println("Connecting to SQL server " + url + " on port " + port);
            con = DriverManager.getConnection(url, username, password);
            stmt = con.createStatement();

        } catch (Exception e) {
            System.err.println("Cannot connect to database server");
            System.err.println(e.getMessage());
            e.printStackTrace();
            //Extra error information provided
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object target = e.getSource();
        ResultSet rs = null;
        String cmd = null;
        if (target.equals(exportButton)) {
            cmd = "select * from population";
        } else if (target.equals(irishPopbyCounty)) {
            cmd = "select * from census16prelim, GROUP BY county;";
        } else if (target.equals(numRecForCellButton)) {
            String idOfCell = countySelector.getText();
            cmd = "select sum(2016) from census16prelim.population where County = " + idOfCell + ";";
        } else if (target.equals(popByCountyforYear)) {
            String year = popNum.getText();
            cmd = "select * from census16prelim.population where year = '" + year + "';";

        }
        try {
            System.out.println("Command is set to: " + cmd);
            rs = stmt.executeQuery(cmd);
            writeToFile(rs);
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    }

    public static void main(String args[]) {
        new JDBCChris("Population Data Export");
    }

    private void writeToFile(ResultSet rs) {
        try {
            FileWriter outputFile = new FileWriter("populationoutput.csv");
            PrintWriter printWriter = new PrintWriter(outputFile);
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumns = rsmd.getColumnCount();

            for (int i = 0; i < numColumns; i++) {
                printWriter.print(rsmd.getColumnLabel(i + 1) + ",");
            }
            printWriter.print("\n");
            while (rs.next()) {
                for (int i = 0; i < numColumns; i++) {
                    printWriter.print(rs.getString(i + 1) + ",");
                }
                printWriter.print("\n");
                printWriter.flush();
            }
            printWriter.close();
        } catch (Exception e) {
            System.out.println("Error Exporting to CSV");
            e.printStackTrace();
        }

    }
}
